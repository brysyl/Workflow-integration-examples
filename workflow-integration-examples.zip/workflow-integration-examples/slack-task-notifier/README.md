# Slack Task Notifier

This project demonstrates how to connect a **task management tool** (Trello/Asana mock API) with **Slack**.

## 🚀 Features
- Fetches task data from an API (mock Trello API).
- Sends new task notifications to a Slack channel.
- Can be scheduled with cron jobs or run as a cloud function.

## 🛠️ Tech Stack
- Python 3.9+
- Slack SDK
- Requests

## 📦 Setup
1. Create a Slack App + bot token (https://api.slack.com/apps).
2. Add **chat:write** scope and install into your workspace.
3. Replace placeholders in `slack_task_notifier.py`:
   - `SLACK_BOT_TOKEN`
   - `CHANNEL_ID`
   - `TASK_API_URL`
4. Run:
   ```bash
   python slack_task_notifier.py
   ```

---
