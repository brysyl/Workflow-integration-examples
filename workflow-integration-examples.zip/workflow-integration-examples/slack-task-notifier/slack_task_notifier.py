import requests
from slack_sdk import WebClient
from slack_sdk.errors import SlackApiError

# 🔑 Slack setup
SLACK_BOT_TOKEN = "xoxb-your-bot-token-here"
CHANNEL_ID = "your-channel-id"

client = WebClient(token=SLACK_BOT_TOKEN)

# 🌐 Mock Task API endpoint
TASK_API_URL = "https://jsonplaceholder.typicode.com/todos"  # Mock Trello/Asana

def fetch_tasks():
    try:
        response = requests.get(TASK_API_URL, timeout=10)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        print(f"❌ Error fetching tasks: {e}")
        return []

def notify_slack(task):
    message = f"""
    📌 *New Task Assigned:*
    *Title:* {task.get('title', 'N/A')}
    *Status:* {"Completed" if task.get("completed") else "In Progress"}
    *Task ID:* {task.get('id')}
    """
    try:
        client.chat_postMessage(channel=CHANNEL_ID, text=message)
        print("✅ Notification sent to Slack.")
    except SlackApiError as e:
        print(f"❌ Error sending to Slack: {e.response['error']}")

if __name__ == "__main__":
    tasks = fetch_tasks()
    if tasks:
        for task in tasks[:3]:  # Limit to first 3 for demo
            notify_slack(task)
